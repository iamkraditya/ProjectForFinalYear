step 1) Import the e-store.sql file in your database.

step 2)Signup as a new user
note: use small letters and numbers only for writing email id.(Ex name111@xyz.com)

step 3)Login

Thanks 