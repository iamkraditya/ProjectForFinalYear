step 1 ) Import the SQL file.

step 2 ) sign up as a new user.

step 3 ) login using the same user id and password.

