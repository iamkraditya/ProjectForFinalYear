<?php
$conn = mysqli_connect('localhost','root','','e-store') or die(mysqli_error($conn));
session_start();
?>
