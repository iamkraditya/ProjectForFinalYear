    <footer>
    <div class="container">
    	<div class="row">
			<div class="col-md-4">
				<h3>Information</h3>
				<p><a href="about.php" style="color:#9d9d9d;">About Us</a></p>
				<p><a href="contact.php" style="color:#9d9d9d;">Contact Us</a></p>
			</div>
			<div class="col-md-4">
				<h3>My Account</h3>
				<p><a href="login.php" style="color:#9d9d9d;">Login</a></p>
				<p><a href="signup.php" style="color:#9d9d9d;">Signup</a></p>
			</div>
			<div class="col-md-4">
				<h3>Contact Us</h3>
				<p>Contact +91-123-000000</p>
			</div>
        </div>
    </div>
    </footer>
    <!--Footer end-->